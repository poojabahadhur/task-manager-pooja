const express = require("express");
const router = express.Router();

let tasks = [];

// GET all tasks
router.get("/", (req, res) => {
  res.json(tasks);
});

// CREATE task
router.post("/", (req, res) => {
  const { title } = req.body;

  if (!title || title.trim() === "") {
    return res.status(400).json({ error: "Title is required" });
  }

  const newTask = {
    id: Date.now().toString(),
    title,
    completed: false,
    createdAt: new Date().toISOString(),
  };

  tasks.push(newTask);
  res.status(201).json(newTask);
});

// UPDATE task
router.patch("/:id", (req, res) => {
  const { id } = req.params;

  const task = tasks.find((t) => t.id === id);
  if (!task) {
    return res.status(404).json({ error: "Task not found" });
  }

  task.completed = !task.completed;
  res.json(task);
});

// DELETE task
router.delete("/:id", (req, res) => {
  const { id } = req.params;

  const exists = tasks.some((t) => t.id === id);
  if (!exists) {
    return res.status(404).json({ error: "Task not found" });
  }

  tasks = tasks.filter((t) => t.id !== id);
  res.json({ message: "Task deleted successfully" });
});

module.exports = router;