export default function TaskItem({ task, onToggle, onDelete }) {
  return (
    <li style={{ margin: "10px 0" }}>
      <span
        style={{
          textDecoration: task.completed ? "line-through" : "none",
          cursor: "pointer",
        }}
        onClick={() => onToggle(task.id)}
      >
        {task.title}
      </span>

      <button onClick={() => onDelete(task.id)} style={{ marginLeft: "10px" }}>
        Delete
      </button>
    </li>
  );
}