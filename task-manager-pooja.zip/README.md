# Task Manager App

This is a simple full-stack Task Manager application built as part of a technical assignment.

## Features
- Create tasks
- View all tasks
- Mark tasks as completed
- Delete tasks

## Tech Stack
- Frontend: React (Vite)
- Backend: Node.js + Express

## Setup Instructions

### Backend
cd backend
npm install
node server.js

### Frontend
cd frontend
npm install
npm run dev

## Notes
- Data is stored in memory
- Focused on clarity and functionality

## Developer Note
Given the time constraint, I focused on keeping the implementation simple, readable, and functional.
